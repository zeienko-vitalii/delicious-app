package com.zeenko.domain;

public class MyClass {
}
